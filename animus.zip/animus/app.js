/* Libek */
var express = require('express');
var app = express();
var http = require("http").createServer(app);
var io = require('socket.io')(http);
var fs = require('fs');

/* Express middleware, static és public mappák*/
app.use(express.static('frontend/public'));
app.use(express.static('frontend'));

/* Express útvonalak */
app.get('/', function(req, res){
	res.sendFile(__dirname + "/frontend/index.html");
});
/* Játék beállításai */
var gameOptions = {
  port: 8080,
  minPlayers: 2,
	gameStarted: false,
	gameEnded: false,
	resetSent: false,
	starterCountdown: 20*10,
	starterTime: 20*10,
	playTime: 30*10,
	playCountdown: 30*10,

	resetGame: function(){
		gameOptions.starterCountdown = gameOptions.starterTime;
		gameOptions.playCountdown = gameOptions.playTime;
		gameOptions.gameStarted = false;
		gameOptions.gameEnded = false;
		gameOptions.resetSent = false;
		for(var i=0;i<gameMatrix.length;i++){
			for(var j=0;j<gameMatrix[i].length;j++){
				gameMatrix[i][j] = 0;
			}
		}
		// new pos
		for(var i=0;i<sockets.length;i++){
			var socket = sockets[i];
			var pos = {
				x: Math.floor(Math.random()*6),
				y: Math.floor(Math.random()*6)
			}

			socket.pos = pos;

			gameMatrix[socket.pos.x][socket.pos.y] = socket.id;
		}
	}
}

var gameMatrix = [];
var scoreList = [];

for(var i=0;i<6;i++){
	gameMatrix[i] = new Array(6);
}

for(var i=0;i<gameMatrix.length;i++){
	for(var j=0;j<gameMatrix[i].length;j++){
		gameMatrix[i][j] = 0;
	}
}


/* Socketek */
var sockets = [];
actID = 1;

io.on('connection', function(socket){
	if(gameOptions.gameStarted==true){
		socket.disconnect();
	}
	/* Socket csatlakozás */
	socket.emit("welcomeLayer");
	console.log("Játékos csatlakozott");
  socket.id = actID;
  actID++;

	var pos = {
		x: Math.floor(Math.random()*6),
		y: Math.floor(Math.random()*6)
	}

	socket.pos = pos;

	gameMatrix[socket.pos.x][socket.pos.y] = socket.id;

  sockets.push(socket);

	socketFunc.updateGameboard();

	/* Socket lecsatlakozás */
	socket.on('disconnect', function(){
		var j=0;
		while(j<sockets.length && sockets[j].id!= socket.id){
			j++;
		}
		if(j<sockets.length){
			gameMatrix[sockets[j].pos.x][sockets[j].pos.y] = 0;
			sockets.splice(j,1);
		}
		console.log("socket disconnected");
	});


  socket.on("inputMsg", function(msg){
    var data = {
      msg: msg.msg,
      sender: socket.username
    }
		if(msg.msg == "reset"){
				gameOptions.resetGame();
				data.msg = socket.username + " új játékot indított!";
				data.sender = "Játékszerver";
		}
    socketFunc.outputMsg(data);
  });

  socket.on("setUsername",function(username){
    socket.username = username;
    var data = {
      msg: username + " csatlakozott a játékba",
      sender: "Játékszerver"
    }
    socketFunc.outputMsg(data);
		socketFunc.updateGameboard();
		socketFunc.updateScore();
  });

	socket.on("posChange",function(pos){
		if(gameOptions.gameStarted==true && gameOptions.gameEnded==false){
			//gameMatrix[socket.pos.x][socket.pos.y] = 0;
			if(socket.pos.x+pos.x < 6 && socket.pos.x+pos.x >= 0){
				socket.pos.x+=pos.x;
			}
			if(socket.pos.y+pos.y < 6 && socket.pos.y+pos.y >= 0){
				socket.pos.y+=pos.y;
			}
			gameMatrix[socket.pos.x][socket.pos.y] = socket.id;
		}
	});

});

socketFunc = {
  outputMsg: function(data){
    var outputMsg = "<b>#" + data.sender + "></b></br> " + data.msg;
    for(var i=0;i<sockets.length;i++){
      var socket = sockets[i];
      socket.emit("outputMsg",outputMsg);
    }
  },

	alertPlayer: function(data){
		var msg = data.msg;
		for(var i=0;i<sockets.length;i++){

			if(data.to != null && sockets[i].id==data.to){
				sockets[i].emit("alertPlayer",data);
			}else{
				sockets[i].emit("alertPlayer",data);
			}

		}
	},

	updateGameboard: function(){
		for(var i=0;i<sockets.length;i++){
			sockets[i].emit("updateGameboard",gameMatrix);
		}
	},

	updateScore: function(){
		var data = {
			scoreList: []
		}
		for(var i=0;i<sockets.length;i++){
			var socketScore = 0;
			for(var j=0;j<gameMatrix.length;j++){
				for(var k=0;k<gameMatrix[j].length;k++){
					if(gameMatrix[j][k]==sockets[i].id){
						socketScore++;
					}
				}
			}
			sockets[i].score = socketScore;
			data.scoreList.push({username: sockets[i].username, score: socketScore});
		}
		for(var i=0;i<data.scoreList.length-1;i++){
			for(var j=1;j<data.scoreList.length;j++){
				if(data.scoreList[i].score<data.scoreList[j].score){
					var sv = data.scoreList[i];
					data.scoreList[i] = data.scoreList[j];
					data.scoreList[j] = sv;
				}
			}
		}
		scoreList = data.scoreList;
		for(var i=0;i<sockets.length;i++){
			//console.log(data);
			sockets[i].emit("updateScore",data);
		}
	}
}

/* Játékmotor */
setInterval(function(){
	socketFunc.updateGameboard();
	socketFunc.updateScore();
	if(sockets.length >= gameOptions.minPlayers){
		if(gameOptions.starterCountdown<=0){
			if(gameOptions.gameStarted==false){
				var data = {
					msg: "A játék elkezdődött!",
					to: null
				}
				socketFunc.alertPlayer(data);
				gameOptions.playCountdown = gameOptions.playTime;
				gameOptions.gameStarted=true;
			}
			if(Math.floor(gameOptions.playCountdown/10) > 0){
				var data = {
					msg: "Játékidő: " + Math.floor(gameOptions.playCountdown/10) + "mp",
					to: null
				}
				socketFunc.alertPlayer(data);
				gameOptions.playCountdown--;
			}else{
				var data = {
					msg: "Játék vége! " + scoreList[0].username + " Nyert!",
					to: null
				}
				socketFunc.alertPlayer(data);
				gameOptions.gameEnded = true;
				if(gameOptions.resetSent==false){
					var data = {
			      msg: "Új játék indításához írd be: 'reset'",
			      sender: "Játékszerver"
			    }
			    socketFunc.outputMsg(data);
					gameOptions.resetSent=true;
				}
			}

		}else{
			var data = {
				msg: "Visszaszámlálás: " + Math.floor(gameOptions.starterCountdown/10),
				to: null
			}
			socketFunc.alertPlayer(data);
			gameOptions.starterCountdown--;
		}
	}else{
		gameOptions.starterCountdown = gameOptions.starterTime;
		var data = {
			msg: "Várakozás további "+ (gameOptions.minPlayers-sockets.length) + " játékosra..",
			to: null
		}
		socketFunc.alertPlayer(data);
	}

},1000/10);







/* A szerver indítása */
http.listen(gameOptions.port, function(){
	console.log("Szerver indítva a következő porton: " + gameOptions.port);
});
