var chatInputBtn = document.getElementById("chat-input-button");
var chatInput = document.getElementById("chat-input");
var chatOutput = document.getElementById("chat-output");
var usernameInput = document.getElementById("username-input");
var welcomeLayer = document.getElementById("welcome-layer");
var gameLayer = document.getElementById("gameboard-wrapper");
var gameAlert = document.getElementById("gameboard-alert");
var scoreList = document.getElementById("score-list");
var gameMatrix = [
  document.getElementById("r1c1"),
  document.getElementById("r1c2"),
  document.getElementById("r1c3"),
  document.getElementById("r1c4"),
  document.getElementById("r1c5"),
  document.getElementById("r1c6"),
  document.getElementById("r2c1"),
  document.getElementById("r2c2"),
  document.getElementById("r2c3"),
  document.getElementById("r2c4"),
  document.getElementById("r2c5"),
  document.getElementById("r2c6"),
  document.getElementById("r3c1"),
  document.getElementById("r3c2"),
  document.getElementById("r3c3"),
  document.getElementById("r3c4"),
  document.getElementById("r3c5"),
  document.getElementById("r3c6"),
  document.getElementById("r4c1"),
  document.getElementById("r4c2"),
  document.getElementById("r4c3"),
  document.getElementById("r4c4"),
  document.getElementById("r4c5"),
  document.getElementById("r4c6"),
  document.getElementById("r5c1"),
  document.getElementById("r5c2"),
  document.getElementById("r5c3"),
  document.getElementById("r5c4"),
  document.getElementById("r5c5"),
  document.getElementById("r5c6"),
  document.getElementById("r6c1"),
  document.getElementById("r6c2"),
  document.getElementById("r6c3"),
  document.getElementById("r6c4"),
  document.getElementById("r6c5"),
  document.getElementById("r6c6")
]

var playerColor = ["yellow","orange","green","purple","red"];
// Fullscreen
function openFullscreen() {
  var elem = gameLayer;
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { /* Firefox */
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE/Edge */
    elem.msRequestFullscreen();
  }
}

// Gombnyomás érzékelő
window.addEventListener("keydown", checkKeyPressed, false);
usernameInput.focus();

function checkKeyPressed(evt) {
	if (evt.keyCode == "13") {
    if(welcomeLayer.style.display != "none"){
      if(usernameInput.value != ""){
        socket.emit("setUsername",usernameInput.value);
        welcomeLayer.style.display = "none";
      }
    }else{
      if(chatInput.value != ""){
        var data={
          msg: chatInput.value
        }
        chatInput.value="";
        socket.emit("inputMsg",data);
      }
    }
	}


  //Nyilak
  if (evt.keyCode == "37" || evt.keyCode == "39" || evt.keyCode == "38" || evt.keyCode == "40"){
    var data = {
      x: 0,
      y: 0
    }
    switch(evt.keyCode){
      case 37:
        data.y = -1;
      break;
      case 38:
        data.x = -1;
      break;
      case 39:
        data.y = 1;
      break;
      case 40:
        data.x = 1;
      break;
    }
    socket.emit("posChange",data);
  }
}

chatInputBtn.addEventListener("click",function(){
  if(chatInput.value != ""){
    var data={
      msg: chatInput.value
    }
    chatInput.value="";
    socket.emit("inputMsg",data);
  }
});


function outputMsg(msg){
  var msgP = document.createElement("P");
  msgP.innerHTML = msg;
  msgP.class = "chat-msg";
  chatOutput.appendChild(msgP);
  chatOutput.scrollTo(0,chatOutput.scrollHeight);
}

function alertPlayer(data){
  var msg = data.msg;
  gameAlert.innerHTML=msg;
}

function updateGameboard(data){
  for(var i=0;i<6;i++){
    for(var j=0;j<6;j++){
      var id=j+((i)*6);
      //console.log(i+"|"+j+"|"+id);
      if(data[i][j]!=0){
        gameMatrix[id].style.backgroundColor = playerColor[data[i][j]];
      }else{
        gameMatrix[id].style.backgroundColor = "rgba(240,240,240,0.9)";
      }
    }
  }
}

function updateScore(data){
  while (scoreList.lastElementChild) {
    scoreList.removeChild(scoreList.lastElementChild);
  }
  for(var i=0;i<data.scoreList.length;i++){
    var scoreE = document.createElement("P");
    scoreE.innerHTML = data.scoreList[i].username + " | "+data.scoreList[i].score + " pont";
    scoreList.appendChild(scoreE);
  }
}
